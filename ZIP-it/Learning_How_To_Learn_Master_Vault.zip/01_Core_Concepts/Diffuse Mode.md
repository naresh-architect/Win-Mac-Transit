---
source: Learning How to Learn
tags: [learning, neuroscience]
---

# Diffuse Mode

Diffuse mode is broad thinking used for insights and new connections.

Related: [[Focused Mode]]