---
source: Learning How to Learn
tags: [learning, neuroscience]
---

# Focused Mode

Focused mode is concentrated attention used for familiar problems and details.

Related: [[Diffuse Mode]]