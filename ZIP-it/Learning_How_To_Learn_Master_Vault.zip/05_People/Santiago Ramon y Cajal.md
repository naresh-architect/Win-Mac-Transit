---
source: Learning How to Learn
tags: [learning, neuroscience]
---

# Santiago Ramon y Cajal

Father of neuroscience. Demonstrated lifelong learning and brain adaptation.