---
source: Learning How to Learn
tags: [learning, neuroscience]
---

# Pomodoro Technique

25 min focus + 5-10 min reward break. Supports focused and diffuse learning.