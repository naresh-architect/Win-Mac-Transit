---
source: Learning How to Learn
tags: [learning, neuroscience]
---

# Procrastination

Avoiding tasks due to discomfort. Reduced by starting small and using Pomodoro.