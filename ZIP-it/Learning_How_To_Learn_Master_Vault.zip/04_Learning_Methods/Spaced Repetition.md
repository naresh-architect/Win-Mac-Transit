---
source: Learning How to Learn
tags: [learning, neuroscience]
---

# Spaced Repetition

Review over time for durable retention.