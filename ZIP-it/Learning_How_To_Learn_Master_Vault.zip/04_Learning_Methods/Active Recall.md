---
source: Learning How to Learn
tags: [learning, neuroscience]
---

# Active Recall

Retrieve from memory instead of rereading.