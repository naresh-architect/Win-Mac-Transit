---
source: Learning How to Learn
tags: [learning, neuroscience]
---

# Sleep and Learning

Sleep consolidates learning and strengthens pathways.