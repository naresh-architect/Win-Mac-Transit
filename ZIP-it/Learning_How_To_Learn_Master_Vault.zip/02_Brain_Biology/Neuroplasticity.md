---
source: Learning How to Learn
tags: [learning, neuroscience]
---

# Neuroplasticity

Learning physically changes the brain.