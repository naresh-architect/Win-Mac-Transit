---
source: Learning How to Learn
tags: [learning, neuroscience]
---

# Dendritic Spines

Neural structures that grow through learning and strengthen during sleep.