Front: What are the two learning modes?
Back: Focused Mode and Diffuse Mode

Front: What strengthens learning during sleep?
Back: Memory consolidation and dendritic spine growth