"""
SupportPilot (LangChain edition, live-only) — provider/model config.

This project always calls a real chat model — there is no offline/mock
mode and no FakeListChatModel anywhere in this codebase or its notebooks.
You need a real API key for whichever provider you select before running
anything that imports this module.

  SUPPORTPILOT_PROVIDER   "anthropic" (default) | "openai"
  SUPPORTPILOT_MODEL      overrides the provider's default model if set
  ANTHROPIC_API_KEY       required when PROVIDER == "anthropic"
  OPENAI_API_KEY          required when PROVIDER == "openai"

get_chat_model() is the single place a real chat model gets constructed.
chains.py uses it to build the three production chains; the learning
notebooks import it directly for every demo, so there is exactly one
implementation of "how do I get a real, live chat model" in this project.
"""
from __future__ import annotations

import os

PROVIDER = os.environ.get("SUPPORTPILOT_PROVIDER", "anthropic")  # "anthropic" | "openai"

_DEFAULT_MODELS = {
    "anthropic": "claude-sonnet-5",
    "openai": "gpt-4o-mini",
}
MODEL = os.environ.get("SUPPORTPILOT_MODEL") or _DEFAULT_MODELS.get(PROVIDER, "claude-sonnet-5")

_REQUIRED_KEY_ENV_VAR = {
    "anthropic": "ANTHROPIC_API_KEY",
    "openai": "OPENAI_API_KEY",
}


def require_api_key() -> None:
    """Fails fast with a clear message instead of letting a confusing
    error surface from deep inside the LangChain provider SDK."""
    key_var = _REQUIRED_KEY_ENV_VAR.get(PROVIDER)
    if key_var and not os.environ.get(key_var):
        raise RuntimeError(
            f"SUPPORTPILOT_PROVIDER is '{PROVIDER}' but {key_var} is not set. "
            f"This project makes real API calls only -- set {key_var} before importing config.py."
        )


def get_chat_model(max_tokens: int = 1000):
    """Builds a real chat model for whichever provider is configured.
    This is the ONLY place a chat model is constructed in this project --
    both chains.py and every notebook call this function rather than
    each building their own ChatAnthropic/ChatOpenAI instance."""
    require_api_key()
    if PROVIDER == "openai":
        from langchain_openai import ChatOpenAI
        return ChatOpenAI(model=MODEL, max_tokens=max_tokens)

    from langchain_anthropic import ChatAnthropic
    return ChatAnthropic(model=MODEL, max_tokens=max_tokens)
