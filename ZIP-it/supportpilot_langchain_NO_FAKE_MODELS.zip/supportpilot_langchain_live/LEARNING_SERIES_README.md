# SupportPilot — LangChain Learning Series (Real Calls Only)

Six notebooks that teach LangChain from scratch, using the SupportPilot
project's real code as the running example instead of toy snippets.

**There is no fake or mock model anywhere in this project or these
notebooks.** Every cell that touches a chat model — starting from
notebook 1 — makes a real, billed API call to whichever provider you
configure. `config.get_chat_model()` is the one place a chat model gets
constructed, and every notebook imports it directly rather than building
its own.

## Setup

```bash
pip install -r requirements.txt
jupyter notebook   # or jupyter lab
```

Open the notebooks in order — each builds on concepts from the last, and
several later notebooks `import` code straight from the earlier ones'
explanations. Run them from *inside* this folder so `import database`,
`import models`, `import tools`, etc. resolve.

**Every notebook needs a real API key before its first model call.** Pick
a provider — each notebook has its own setup cells near the top (or near
the first model-calling section, for notebook 4):

| Provider | Env vars needed | Default model |
|---|---|---|
| Anthropic (default) | `ANTHROPIC_API_KEY` | `claude-sonnet-5` |
| OpenAI | `SUPPORTPILOT_PROVIDER=openai`, `OPENAI_API_KEY` | `gpt-4o-mini` |

Set `SUPPORTPILOT_MODEL` to override either provider's default. If you
forget to set a key, `config.get_chat_model()` (and `config.require_api_key()`,
which it calls internally) fails immediately with a clear message rather
than a confusing error from deep inside a provider SDK.

## Notebook order

| # | Notebook | Covers | Makes real API calls? |
|---|----------|--------|---|
| 1 | `01_langchain_foundations.ipynb` | Messages, chat models, `ChatPromptTemplate`, your first `\|` chain | **Yes**, from Section 1.3 onward |
| 2 | `02_output_parsers_structured_output.ipynb` | `StrOutputParser`, `PydanticOutputParser`, `with_structured_output` | **Yes**, throughout |
| 3 | `03_lcel_and_runnables.ipynb` | `RunnableLambda`, `RunnableSequence`, `RunnableParallel` | **Yes**, Sections 3.2 onward (3.1 and 3.3 are pure-Python, no model) |
| 4 | `04_tools_and_function_calling.ipynb` | `@tool`, direct invocation vs. real model-driven tool selection | **Yes**, Section 4.3 onward |
| 5 | `05_embeddings_vectorstores_retrieval.ipynb` | `Embeddings` interface, FAISS, retrievers (RAG) | No — retrieval is offline TF-IDF regardless of provider, by design |
| 6 | `06_full_pipeline_walkthrough.ipynb` | Everything combined — runs the real `pipeline.py` end to end | **Yes**, throughout |

Every notebook ends with a hands-on exercise that extends the real project
code (not a disconnected toy problem), and now every exercise that touches
a model is a real call too — there's no "imagine what this would do"
framing left anywhere in the series.

## Why notebook 5 is the one exception

Retrieval never calls a chat model — `KnowledgeRetriever` is built on
TF-IDF + FAISS, entirely offline, regardless of which provider you've
configured for the chains that *do* call a model. This isn't a leftover
mock; it's a deliberate project design choice (see `retrieval.py`'s
docstring) to keep KB search free and fast. If you want real semantic
embeddings instead, swap `embeddings.py`'s `LocalTfidfEmbeddings` for
`OpenAIEmbeddings` or `HuggingFaceEmbeddings` — that's a separate decision
from which chat model provider you're using for classify/draft/validate.

## A note on how these were built

These notebooks were authored and syntax-checked (every code cell parses
as valid Python via `ast.parse`), and `config.py`'s `get_chat_model()` and
`require_api_key()` logic was tested directly (confirmed it raises without
a key, resolves the correct default model per provider, and passes once a
key is set). LangChain and the provider SDKs (`langchain-anthropic`,
`langchain-openai`) were not installed in the environment used to write
this, so the real API calls themselves were not executed end-to-end before
delivery — that's the part you'll be verifying for the first time when you
run these.
