# SupportPilot — LangChain Edition (Live Mode Only)

Same system as the original SupportPilot solution — classify -> account
lookup + KB retrieval -> draft -> validate -> escalate -> case report —
rebuilt on top of LangChain primitives instead of plain function calls.

**This version has no mock/offline mode.** Every classify/draft/validate
call goes to a real chat model. You need a real API key before running
anything that touches `chains.py`.

## What changed vs. the original solution

| Piece | Original | LangChain edition |
|---|---|---|
| Classify / Draft / Validate | Python functions in `llm_client.py` | LCEL chains (`ChatPromptTemplate \| <chat model> \| parser`) in `chains.py` |
| Knowledge retrieval | Custom TF-IDF class in `retrieval.py` | `FAISS.from_documents()` + `.as_retriever()`, backed by a LangChain `Embeddings` implementation |
| DB / KB access | Plain functions | `@tool`-decorated LangChain Tools in `tools.py` |
| Orchestration | Sequential Python calls | LCEL `RunnableParallel` for the two independent lookups, `.invoke()` chaining for the rest |
| Escalation logic | Plain Python | **Unchanged, deliberately.** See "Why escalation stays outside LangChain" below. |
| Database, models, KB docs, escalation rules | — | **Unchanged, reused as-is** |

## Quick start

```bash
pip install -r requirements.txt

# Anthropic (default provider)
export ANTHROPIC_API_KEY=sk-ant-...
python3 main.py --init-db
python3 main.py --test-suite

# OpenAI instead
export SUPPORTPILOT_PROVIDER=openai
export OPENAI_API_KEY=sk-...
python3 main.py --init-db
python3 main.py --test-suite
```

`SUPPORTPILOT_MODEL` overrides the model name for whichever provider is
active; if unset, each provider gets its own default (`claude-sonnet-5`
for Anthropic, `gpt-4o-mini` for OpenAI — check each provider's current
docs, since model names move faster than this repo will).

**If you forget to set the right API key**, `chains.py` fails immediately
at import time with a clear message (via `config.require_api_key()`)
rather than letting a confusing error surface from deep inside the
provider SDK on the first `.invoke()` call.

Running `--test-suite` now makes **real API calls for every one of the 8
scenarios** — expect it to take longer and cost a small amount of API
credit compared to the mock-mode version. There's no way to iterate on
pipeline logic for free anymore; that trade-off is the point of this
version.

## Project layout

```
supportpilot_langchain/
├── models.py             Pydantic schemas (unchanged from original)
├── database.py           Mock SQLite DB (unchanged — "mock" here means fictional seed data, unrelated to LLM mode)
├── escalation_rules.py   Deterministic escalation gates (unchanged from original)
├── embeddings.py         Offline TF-IDF Embeddings class (LangChain Embeddings interface)
├── retrieval.py          FAISS vector store + retriever over kb/*.md
├── tools.py              @tool-decorated DB and KB lookup tools
├── config.py             Provider/model selection, get_chat_model(), fail-fast API key check
├── chains.py             LCEL chains for classify / draft / validate — live calls only
├── pipeline.py           Orchestrates chains + tools into the full ticket flow
├── test_tickets.py       Same 8 scenarios as the original solution — now real API calls
├── main.py               CLI
├── kb/                   Same 5 policy markdown docs
└── requirements.txt
```

## Why escalation stays outside LangChain

`escalation_rules.py` is untouched on purpose. It's plain Python `if`
statements with no chain, no tool, no model call — because the whole
point of the hard-category gate (fraud, duplicate charges, high-value
refunds, explicit "get me a manager" requests) is that it must fire the
same way no matter how the ticket is phrased. Wrapping it in a chain
would mean a prompt is involved somewhere in the decision, which is
exactly the surface a rephrased ticket could exploit. `test_tickets.py`
cases 4 and 5 (same fraud report, one blunt, one hedged) both need to
escalate — that's the check, and now it's checking against a real model's
classification instead of a keyword heuristic.

## Why retrieval still uses an offline Embeddings class

Retrieval is unaffected by the live-only change — `KnowledgeRetriever`
doesn't call a chat model at all, so it stays free, fast, and offline via
TF-IDF regardless of which provider you've configured for the chains that
*do* call a model. If you want real semantic embeddings, swap
`embeddings.py`'s `LocalTfidfEmbeddings` for `OpenAIEmbeddings` or
`HuggingFaceEmbeddings` in `retrieval.py` — nothing else needs to change.

## A note on testing in this environment

`langchain`, `langchain-anthropic`, and `langchain-openai` are not
installed in the sandbox this was built in (no network access to `pip
install` them), so `chains.py`, `config.py`, `pipeline.py`, `tools.py`,
and `retrieval.py` were written carefully against the current LangChain
API and syntax-checked (`python3 -m py_compile`), but the actual live API
calls were **not** executed end-to-end here. `config.py`'s fail-fast
`require_api_key()` logic *was* tested directly (confirmed it raises
without a key and passes with one set). `database.py`, `escalation_rules.py`,
and `models.py` are unchanged carryovers from the fully-tested original
solution.

Before your demo:
```bash
pip install -r requirements.txt
export ANTHROPIC_API_KEY=...   # or the OpenAI equivalent
python3 main.py --init-db
python3 main.py --test-suite
```

## Extending further

- Swap `chains.py`'s plain LCEL sequencing for a `SelectorGroupChat`-style
  dynamic router (Week 4) if you want the system to decide which agent
  runs next based on ticket content, rather than a fixed sequence.
- Wrap `tools.py`'s tools behind an MCP server (Week 5) instead of calling
  them directly — this is a very small step from here, since they're
  already framework-native Tool objects.
