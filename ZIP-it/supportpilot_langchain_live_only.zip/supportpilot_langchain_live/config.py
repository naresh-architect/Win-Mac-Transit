"""
SupportPilot (LangChain edition, live-only) — provider/model config.

This project always calls a real chat model — there is no offline/mock
mode. You need a real API key for whichever provider you select before
running anything that touches chains.py.

  SUPPORTPILOT_PROVIDER   "anthropic" (default) | "openai"
  SUPPORTPILOT_MODEL      overrides the provider's default model if set
  ANTHROPIC_API_KEY       required when PROVIDER == "anthropic"
  OPENAI_API_KEY          required when PROVIDER == "openai"
"""
from __future__ import annotations

import os

PROVIDER = os.environ.get("SUPPORTPILOT_PROVIDER", "anthropic")  # "anthropic" | "openai"

_DEFAULT_MODELS = {
    "anthropic": "claude-sonnet-5",
    "openai": "gpt-4o-mini",
}
MODEL = os.environ.get("SUPPORTPILOT_MODEL") or _DEFAULT_MODELS.get(PROVIDER, "claude-sonnet-5")

_REQUIRED_KEY_ENV_VAR = {
    "anthropic": "ANTHROPIC_API_KEY",
    "openai": "OPENAI_API_KEY",
}


def require_api_key() -> None:
    """Fails fast with a clear message instead of letting a confusing
    error surface from deep inside the LangChain provider SDK."""
    key_var = _REQUIRED_KEY_ENV_VAR.get(PROVIDER)
    if key_var and not os.environ.get(key_var):
        raise RuntimeError(
            f"SUPPORTPILOT_PROVIDER is '{PROVIDER}' but {key_var} is not set. "
            f"This project runs in live mode only -- set {key_var} before importing chains.py."
        )
