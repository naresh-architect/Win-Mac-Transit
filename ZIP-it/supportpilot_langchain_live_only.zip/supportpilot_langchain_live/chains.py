"""
SupportPilot (LangChain edition, live-only) — Chains (Week 2, Section 1.4:
"LangChain Foundations" — prompt templates, chaining, output parsers).

Every function below returns a real LangChain Runnable that calls a real
chat model -- there is no mock/offline branch in this version. Set
SUPPORTPILOT_PROVIDER (see config.py) to choose Anthropic or OpenAI, and
set that provider's API key before importing this module.

Both providers implement LangChain's `with_structured_output()` via native
tool calling, so build_classification_chain() and build_validation_chain()
work identically either way -- that's the payoff of coding against the
Runnable/chat-model interface rather than a specific provider's SDK.
"""
from __future__ import annotations

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda

from config import MODEL, PROVIDER, require_api_key
from models import TicketClassification, ValidationResult

require_api_key()  # fail fast, at import time, with a clear message


def _get_chat_model():
    """Builds the live chat model for whichever provider is configured."""
    if PROVIDER == "openai":
        from langchain_openai import ChatOpenAI
        return ChatOpenAI(model=MODEL, max_tokens=1000)

    from langchain_anthropic import ChatAnthropic
    return ChatAnthropic(model=MODEL, max_tokens=1000)


# ---------------------------------------------------------------------------
# 1. Classification chain
# ---------------------------------------------------------------------------

def build_classification_chain():
    prompt = ChatPromptTemplate.from_messages([
        ("system",
         "You classify ShopStream India customer support tickets accurately and conservatively. "
         "If the ticket is ambiguous, reflect that with a lower confidence score rather than guessing."),
        ("human", "ticket_id: {ticket_id}\nticket_text: {ticket_text}"),
    ])
    llm = _get_chat_model().with_structured_output(TicketClassification)
    return prompt | llm | RunnableLambda(lambda result: result.model_dump())


# ---------------------------------------------------------------------------
# 2. Drafting chain
# ---------------------------------------------------------------------------

def build_drafting_chain():
    prompt = ChatPromptTemplate.from_messages([
        ("system",
         "You draft ShopStream India customer support responses. Ground every factual claim "
         "ONLY in the provided kb_chunks and customer context. Never invent a policy detail. "
         "Be concise, and lead with empathy if the customer's sentiment is frustrated or angry."),
        ("human",
         "classification: {classification}\ncustomer_context: {customer_ctx}\nkb_chunks: {kb_chunks}"),
    ])
    llm = _get_chat_model()
    return prompt | llm | StrOutputParser()


# ---------------------------------------------------------------------------
# 3. Validation chain
# ---------------------------------------------------------------------------

def build_validation_chain():
    prompt = ChatPromptTemplate.from_messages([
        ("system",
         "You are a strict QA validator for customer support drafts. Check: (1) every factual "
         "claim is grounded in kb_chunks, (2) nothing promised exceeds stated policy, (3) tone "
         "matches the customer's sentiment. Be conservative — when unsure, fail the check."),
        ("human", "draft: {draft}\nkb_chunks: {kb_chunks}\nclassification: {classification}"),
    ])
    llm = _get_chat_model().with_structured_output(ValidationResult)
    return prompt | llm | RunnableLambda(lambda result: result.model_dump())


# Built once at import time, reused across every ticket
classification_chain = build_classification_chain()
drafting_chain = build_drafting_chain()
validation_chain = build_validation_chain()
