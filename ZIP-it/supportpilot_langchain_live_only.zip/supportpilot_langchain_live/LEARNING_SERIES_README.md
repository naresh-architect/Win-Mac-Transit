# SupportPilot — LangChain Learning Series (Live Mode Only)

Six notebooks that teach LangChain from scratch, using the SupportPilot
project's real code as the running example instead of toy snippets.

**This edition of the project has no mock/offline mode.** `chains.py`
always calls a real chat model. Notebooks 1-5 still use LangChain's
`FakeListChatModel` where the point is teaching a LangChain *concept*
(the `.invoke()` contract, output parsing mechanics) rather than
demonstrating the actual project — those cells run with no API key.
**Notebook 6 is different: every cell that imports `pipeline` or `chains`
makes real, billed API calls.**

## Setup

```bash
pip install -r requirements.txt
jupyter notebook   # or jupyter lab
```

Open the notebooks in order — each builds on concepts from the last, and
several later notebooks `import` code straight from the earlier ones'
explanations. Run them from *inside* this folder so `import database`,
`import models`, `import tools`, etc. resolve.

**You need a real API key before notebook 6.** Pick a provider:

| Provider | Env vars needed | Default model |
|---|---|---|
| Anthropic (default) | `ANTHROPIC_API_KEY` | `claude-sonnet-5` |
| OpenAI | `SUPPORTPILOT_PROVIDER=openai`, `OPENAI_API_KEY` | `gpt-4o-mini` |

Set `SUPPORTPILOT_MODEL` to override either provider's default. Switching
providers never requires touching `pipeline.py`, `tools.py`, or
`retrieval.py` — only `chains.py`'s `_get_chat_model()` branches on
`SUPPORTPILOT_PROVIDER`. If you forget to set a key, `config.py`'s
`require_api_key()` fails immediately at import time with a clear message
rather than a confusing error from deep inside a provider SDK.

## Notebook order

| # | Notebook | Covers | Needs a real API key? |
|---|----------|--------|---|
| 1 | `01_langchain_foundations.ipynb` | Messages, chat models, `ChatPromptTemplate`, your first `\|` chain | No — uses `FakeListChatModel` |
| 2 | `02_output_parsers_structured_output.ipynb` | `StrOutputParser`, `PydanticOutputParser`, `with_structured_output` | No — uses `FakeListChatModel` |
| 3 | `03_lcel_and_runnables.ipynb` | `RunnableLambda`, `RunnableSequence`, `RunnableParallel` | No |
| 4 | `04_tools_and_function_calling.ipynb` | `@tool`, direct invocation vs. model-driven tool selection | No (real tool-calling demo is commented out) |
| 5 | `05_embeddings_vectorstores_retrieval.ipynb` | `Embeddings` interface, FAISS, retrievers (RAG) | No — offline TF-IDF |
| 6 | `06_full_pipeline_walkthrough.ipynb` | Everything combined — runs the real `pipeline.py` end to end | **Yes — real, billed calls** |

Every notebook ends with a hands-on exercise that extends the real project
code (not a disconnected toy problem) — do these before moving to the next
notebook; later notebooks assume you've seen the earlier project modules
run, not just read about them.

## Why notebooks 1-5 still use `FakeListChatModel` in a live-only project

These fake models teach the LangChain *interface* (every chat model,
real or fake, implements `.invoke()` the same way) — that lesson doesn't
depend on whether the actual SupportPilot project has a mock mode. Only
notebook 3's `RunnableLambda` section changed meaningfully from the
mock+live version of this series: it used to point at a real mock branch
inside `chains.py` that no longer exists, so it now teaches the same
stub-for-testing pattern as a general technique instead of a description
of current project code.

## A note on how these were built

These notebooks were authored and syntax-checked (every code cell parses as
valid Python via `ast.parse`), and `config.py`'s fail-fast API-key logic
was tested directly (confirmed it raises without a key, passes with one
set). LangChain and the provider SDKs (`langchain-anthropic`,
`langchain-openai`) were not installed in the environment used to write
this, so the actual live API calls in notebook 6 were not executed
end-to-end before delivery — that's the one part of this series you'll be
verifying for the first time yourself.
