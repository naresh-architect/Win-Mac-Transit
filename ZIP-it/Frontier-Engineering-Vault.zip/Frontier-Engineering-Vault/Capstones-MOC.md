---
tags: [moc]
---

# Capstones — Map of Content

| Capstone | Week | Fictional Org |
|---|---|---|
| [[SmartIntake-Pharma]] | [[Week-2-LLM-Foundations]] | [[PharmaCore-India]] |
| [[SmartIntake-AML]] | [[Week-2-LLM-Foundations]] | [[FinBridge-Solutions]] |
| [[CodeCompass]] | [[Week-3-RAG-Pipelines]] | — |
| [[CourseCompass]] | [[Week-3-RAG-Pipelines]] | — |
| [[ClaimSense]] | [[Week-3-RAG-Pipelines]] | [[SecureShield-Insurance]] |
| [[SupportPilot]] | [[Week-4-Agentic-AI]] | [[ShopStream-India]] |
| [[CareRoute]] | [[Week-4-Agentic-AI]] | [[CareWell-Health-Network]] |
| [[BankForge]] | [[Week-5-MCP]] | [[NeoBank-India]] |
| [[Nexus-Capstone]] | [[Week-6-Nexus]] | [[Meridian-Financial-Group]] |

Back to [[00-Home]]
