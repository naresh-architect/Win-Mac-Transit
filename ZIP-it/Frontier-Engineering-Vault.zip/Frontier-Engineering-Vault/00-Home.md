---
tags: [moc, programme]
---

# 6-Week Immersive Programme — Frontier Engineering

> From LLM Fundamentals to Production-Ready AI Systems
> New Joiner Technical Training | Level 2 — Working Knowledge

This vault is the Map of Content (MOC) for the Frontier Engineering curriculum. Every week, capstone, fictional organisation, technical topic, and behavioral topic is its own note, cross-linked so you can navigate the way you actually think about the programme — by week, by skill, by domain, or by behaviour.

## The Three Pillars

- [[Technology-MOC|Technology]] — LLM APIs → RAG → Multi-Agent Systems → MCP → Deployment
- [[Domains-MOC|Domain]] — Every capstone lives inside a real, regulated industry
- [[Behaviour-MOC|Frontier Behaviour]] — Ownership, ethics, client communication, governance

## The Six Weeks

| Week | Focus | Capstone |
|---|---|---|
| [[Week-1-Boot-Camp]] | Professional foundations | Gamified boot camp assessment |
| [[Week-2-LLM-Foundations]] | LLM APIs, prompting, LangChain | [[SmartIntake-Pharma]] *or* [[SmartIntake-AML]] |
| [[Week-3-RAG-Pipelines]] | Embeddings, retrieval, evaluation | [[CodeCompass]] *or* [[CourseCompass]] *or* [[ClaimSense]] |
| [[Week-4-Agentic-AI]] | Agents, orchestration, MCP preview | [[SupportPilot]] *or* [[CareRoute]] |
| [[Week-5-MCP]] | MCP servers, guardrails, deployment | [[BankForge]] |
| [[Week-6-Nexus]] | Final integrative capstone | [[Nexus-Capstone]] |

## Quick Links

- [[Capstones-MOC|All Capstones]]
- [[Domains-MOC|All Fictional Organisations]]
- [[Technology-MOC|All Technical Topics]]
- [[Behaviour-MOC|All Behavioral Topics]]
- [[More-Behavioral-Scenarios]]

## The One-Sentence Version

Frontier Engineering takes a new joiner from a professional-conduct boot camp, through LLM foundations, RAG, agentic AI, and MCP, into a final capstone ([[Nexus-Capstone]]) that forces all four technical weeks to work together in one deployed system — with a behavioral case study embedded in every week so technical skill and professional accountability are trained side by side, never separately.
