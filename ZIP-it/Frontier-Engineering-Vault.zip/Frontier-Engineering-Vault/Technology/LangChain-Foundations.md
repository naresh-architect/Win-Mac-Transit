---
tags: [technology, week2]
---

# LangChain Foundations

**Week:** [[Week-2-LLM-Foundations]] (Section 1.4)

## Covers
- Prompt templates
- LLMChain / direct model calls
- Output parsers
- Chaining LLM calls (output of one step feeds the next)

## Used In
[[SmartIntake-Pharma]] · [[SmartIntake-AML]] · [[RAG-Fundamentals]] · [[Multi-Agent-Systems]]
