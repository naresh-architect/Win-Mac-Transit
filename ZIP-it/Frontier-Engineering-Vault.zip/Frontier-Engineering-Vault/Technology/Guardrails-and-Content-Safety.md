---
tags: [technology, week5]
---

# Guardrails & Content Safety

**Week:** [[Week-5-MCP]] (Section 4.5a)

## Why This Section Exists
[[Structured-Output-and-Function-Calling|Pydantic]] (Week 2) validates that output is correctly *shaped*. It cannot catch a prompt injection, PII leaking in output, or a jailbroken-but-well-typed response. This is the layer above structural validation.

## The Four-Layer Safety Stack
Input sanitisation → prompt injection defence → LLM call → output filtering + PII handling

## Covers
- **Prompt injection defence** — direct vs. indirect injection; input boundary enforcement; instruction hierarchy; detection heuristics
- **Input sanitisation** — length limits, allow/blocklists, encoding normalisation, markup stripping
- **Output filtering** — regex/keyword scanning, secondary classifiers, groundedness checks (ties back to [[RAGAS-Evaluation]] faithfulness), confidence thresholds
- **PII handling** — regex + NER detection, Microsoft Presidio, redaction/pseudonymisation/minimisation, logging & audit trail rules (GDPR, India DPDP Act, HIPAA)

## Used In
[[BankForge]] · [[Nexus-Capstone]] (mandatory, wraps every layer)
