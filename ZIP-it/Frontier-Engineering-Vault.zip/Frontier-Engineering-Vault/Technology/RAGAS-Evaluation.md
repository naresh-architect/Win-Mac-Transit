---
tags: [technology, week3]
---

# RAGAS Evaluation

**Week:** [[Week-3-RAG-Pipelines]] (Section 2.2 — introduced *before* ingestion, deliberately)

## The Four Metrics
- Faithfulness
- Answer relevancy
- Context precision
- Context recall

## Philosophy
Learners define what "good" looks like before building anything, then re-run RAGAS after every pipeline change — measuring before optimising.

## Reappears In
[[Guardrails-and-Content-Safety]]'s groundedness checks connect back to RAGAS faithfulness in [[Week-5-MCP]].

## Used In
[[CodeCompass]] · [[CourseCompass]] · [[ClaimSense]]
