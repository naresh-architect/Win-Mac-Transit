---
tags: [technology, week3]
---

# RAG Fundamentals

**Week:** [[Week-3-RAG-Pipelines]] (Sections 2.1, 2.3, 2.5–2.7)

## Covers
- The RAG problem statement and why it exists
- Document ingestion & chunking (fixed-size, sentence, recursive)
- The end-to-end chain: raw data → chunks → embeddings → retrieval → generation
- Query expansion and re-ranking
- Structured/CSV/SQL RAG
- Multimodal RAG (text + tables + images)

## Depends On
[[Embeddings-and-Vector-Databases]] · [[LangChain-Foundations]]

## Evaluated With
[[RAGAS-Evaluation]]

## Used In
[[CodeCompass]] · [[CourseCompass]] · [[ClaimSense]] · [[Nexus-Capstone]]
