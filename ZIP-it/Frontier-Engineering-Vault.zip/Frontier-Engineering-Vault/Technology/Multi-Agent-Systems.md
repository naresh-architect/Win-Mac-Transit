---
tags: [technology, week4]
---

# Multi-Agent Systems (MAS)

**Week:** [[Week-4-Agentic-AI]] (Sections 3.1–3.5)

## Covers
- The single-agent bottleneck — why one agent, too many tools, underperforms
- The "Project Team" analogy — one agent, one role
- Framework comparison: LangChain (pipeline/graph) vs. AutoGen (conversation-driven) vs. CrewAI (role-based teams)
- Orchestration: RoundRobinGroupChat (fixed sequence) vs. SelectorGroupChat (dynamic routing)
- Agent observability ("Teenager Framework"): step tracking, cost, latency, token usage
- Human-in-the-loop design

## Feeds Into
[[Model-Context-Protocol]] preview (Section 3.6) sets up [[Week-5-MCP]]

## Used In
[[SupportPilot]] · [[CareRoute]] · [[Nexus-Capstone]]
