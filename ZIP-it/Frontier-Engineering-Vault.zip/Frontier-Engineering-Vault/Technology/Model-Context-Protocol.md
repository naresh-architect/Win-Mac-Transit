---
tags: [technology, week4, week5]
---

# Model Context Protocol (MCP)

**Previewed:** [[Week-4-Agentic-AI]] (Section 3.6, concepts only)
**Built end-to-end:** [[Week-5-MCP]] (Sections 4.1–4.4, 4.6)

## The Idea
"USB-C for AI" — a universal connector bridging LLMs to external systems without hardcoded, duplicate, fragile integrations.

## The Three Primitives
- **Tools** — actions the AI can execute (side effects, computations)
- **Resources** — read-only data injected into context
- **Prompts** — reusable instruction templates

## Architecture
Host Application → MCP Client → Protocol Layer → MCP Server. Transport-agnostic: stdio (local) or streamable HTTP (remote).

## Building
FastMCP library, `@mcp.tool()` / `@mcp.resource()` decorators, MCP Inspector for debugging.

## Wrapped By
[[Guardrails-and-Content-Safety]] · deployed via [[Production-Deployment]]

## Used In
[[BankForge]] · [[Nexus-Capstone]]
