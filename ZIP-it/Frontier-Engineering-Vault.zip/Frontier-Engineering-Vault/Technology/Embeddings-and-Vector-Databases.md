---
tags: [technology, week3]
---

# Embeddings & Vector Databases

**Week:** [[Week-3-RAG-Pipelines]] (Section 2.4)

## Covers
- Word2Vec vs. SentenceTransformer embeddings
- FAISS, pgvector, Chroma — when to use each
- Indexing and similarity search
- Embedding caching for latency/cost
- Hybrid search — BM25 keyword + semantic

## Used In
[[RAG-Fundamentals]] · [[CodeCompass]] · [[CourseCompass]] · [[ClaimSense]]
