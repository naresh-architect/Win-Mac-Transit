---
tags: [technology, week5]
---

# Production Deployment

**Week:** [[Week-5-MCP]] (Section 4.7, dedicated half-day)

## Why This Section Exists
Ensures every learner finishes having *deployed* a real system, not just run one locally.

## Covers
- Containerisation with Docker — Dockerfile, build, run
- Environment management — `.env` files, secrets, never hardcode API keys
- Key rotation, principle of least privilege
- Structured JSON logging, log levels
- Health check endpoints, latency tracking, error-rate alerting
- Phased rollout — pilot → parallel → replace

## Used In
[[BankForge]] · [[Nexus-Capstone]] (mandatory Docker Compose deployment with health checks)
