---
tags: [technology, week2]
---

# LLM APIs, Tokens & the Context Window

**Week:** [[Week-2-LLM-Foundations]] (Section 1.1)

## Covers
- Token mechanics, context windows, cost implications
- Temperature, top-p, sampling
- OpenAI and Anthropic API structure, authentication, response parsing
- Streaming responses for low-latency UX
- Cost/token management — max_tokens, avoiding runaway calls
- Transformer architecture at a conceptual level

## Feeds Into
[[Prompt-Engineering]] · [[Structured-Output-and-Function-Calling]] · [[SmartIntake-Pharma]] · [[SmartIntake-AML]]
