---
tags: [technology, week2]
---

# Prompt Engineering Patterns

**Week:** [[Week-2-LLM-Foundations]] (Section 1.2)

## Covers
- Zero-shot, few-shot, chain-of-thought prompting
- System messages and persona setting
- Role prompting and instruction-following
- Negative prompting
- Prompt chaining across multiple calls

## Used In
[[SmartIntake-Pharma]] · [[SmartIntake-AML]] · every downstream capstone
