---
tags: [technology, week2]
---

# Structured Output & Function Calling

**Week:** [[Week-2-LLM-Foundations]] (Section 1.3)

## Covers
- JSON mode / structured output
- Function calling / tool use
- **Pydantic validation** — the foundation [[Guardrails-and-Content-Safety]] later builds on top of
- Error handling: retries, fallbacks, graceful degradation

## Critical Cross-Reference
Section 4.5a ([[Guardrails-and-Content-Safety]], in [[Week-5-MCP]]) explicitly revisits Pydantic here to explain what structural validation *cannot* catch — prompt injection, PII leakage, jailbroken-but-well-typed output.

## Used In
[[SmartIntake-Pharma]] · [[SmartIntake-AML]] · [[Nexus-Capstone]]
