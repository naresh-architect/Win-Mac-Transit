---
tags: [technology, week2]
---

# Conversation Memory & Multi-Turn Chat

**Week:** [[Week-2-LLM-Foundations]] (Section 1.5)

## Covers
- ConversationBufferMemory vs. ConversationSummaryMemory
- Managing context window limits in long conversations
- Building a persistent-memory CLI chatbot

## Used In
[[SmartIntake-Pharma]] · [[SmartIntake-AML]] — the multi-turn "ask only for missing fields" requirement
