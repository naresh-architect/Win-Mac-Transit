---
tags: [moc]
---

# Domains — Map of Content

| Org | Industry | Capstone |
|---|---|---|
| [[PharmaCore-India]] | Pharmaceutical regulatory compliance | [[SmartIntake-Pharma]] |
| [[FinBridge-Solutions]] | Financial services — AML/compliance | [[SmartIntake-AML]] |
| [[SecureShield-Insurance]] | Insurance claims intelligence | [[ClaimSense]] |
| [[ShopStream-India]] | E-commerce customer support | [[SupportPilot]] |
| [[CareWell-Health-Network]] | Healthcare triage coordination | [[CareRoute]] |
| [[NeoBank-India]] | Digital banking | [[BankForge]] |
| [[Meridian-Financial-Group]] | Unified financial services | [[Nexus-Capstone]] |

Back to [[00-Home]]
