---
tags: [behaviour, week4]
---

# Responsible AI & Governance

**Week:** [[Week-4-Agentic-AI]] (Section 3.7)

## Why Here
Week 4 is where learners start designing systems that make autonomous decisions on behalf of a business — bias risk and validation gaps stop being abstract and start being design choices.

## Case Studies
- **AI Ethics** — recommendations favour high-value users, ignoring others; bias detected. → **Ethics Escalation Discussion.** Expected: state concern clearly, justify via fairness/compliance impact, recommend action confidently.
- **Governance** — AI features shipping without consistent validation; recurring issues. → **Guardrails Design Workshop.** Expected: define validation process, assign ownership, balance speed vs. reliability.

## Related
[[Client-Communication-and-Storytelling]] · [[Collaboration-and-Decision-Ownership]] · [[Behaviour-MOC]]
