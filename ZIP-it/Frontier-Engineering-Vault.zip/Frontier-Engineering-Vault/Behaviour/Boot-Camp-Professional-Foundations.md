---
tags: [behaviour, week1]
---

# Boot Camp — Professional Foundations

**Week:** [[Week-1-Boot-Camp]]

The baseline every later behavioral case study assumes: etiquette, D&I, remote working ethics, email etiquette, client interfacing, conference call conduct, teamwork, interview clinic.

## Assessed By
Gamified boot camp scores, trainer-based evaluation, techstack skill-based BH assessment.

## Feeds Into
[[AI-Ownership-and-Accountability]] · [[Behaviour-MOC]]
