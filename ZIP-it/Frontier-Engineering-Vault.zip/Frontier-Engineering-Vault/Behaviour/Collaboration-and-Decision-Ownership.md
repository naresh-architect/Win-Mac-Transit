---
tags: [behaviour, week5]
---

# Collaboration & Decision Ownership

**Week:** [[Week-5-MCP]] (Section 4.9)

## Why Here
Week 5's MCP ecosystems are typically built by more than one engineer, and [[BankForge]] forces trade-off calls (scoped access vs. convenience, cost vs. accuracy) no single person should make alone.

## Case Studies
- **Collaboration** — developer and ML engineer disagree (speed vs. accuracy); discussion turns unproductive. → **Team Alignment Meeting.** Expected: listen actively, encourage both views, drive consensus.
- **Decision Ownership** — client demands cost reduction; the cheaper model reduces accuracy significantly. → **Client Decision Discussion.** Expected: evaluate trade-offs, recommend a balanced approach, own the recommendation.

## Related
[[Responsible-AI-and-Governance]] · [[Capstone-Support-Behaviour]] · [[Behaviour-MOC]]
