---
tags: [behaviour, week2]
---

# AI Ownership & Accountability

**Week:** [[Week-2-LLM-Foundations]] (Section 1.6)

## Why Here
Week 2 is the first place learners ship code whose output they must own and explain — the point where technical practice and professional accountability start reinforcing each other.

## Case Studies
- **AI Ownership** — AI-generated code passes testing but produces inconsistent production results; the engineer delays reporting. → **Issue Escalation Meeting.** Expected: report immediately, own it, explain without blaming the AI, share fix + prevention.
- **Problem Solving** — AI provides partial business-rule logic that fails for certain segments, undocumented. → **Debugging Discussion.** Expected: structured questioning, edge-case investigation, validate rather than assume.

## Related
[[Boot-Camp-Professional-Foundations]] · [[Client-Communication-and-Storytelling]] · [[Behaviour-MOC]]
