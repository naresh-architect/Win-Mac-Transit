---
tags: [behaviour, week3]
---

# Client Communication & Storytelling

**Week:** [[Week-3-RAG-Pipelines]] (Section 2.8)

## Why Here
Week 3 is where learners start explaining retrieval/grounding behaviour to non-technical stakeholders — a RAG system behaving inconsistently on similar inputs is a natural, realistic client conversation.

## Case Studies
- **AI Communication** — client asks why the system behaves differently for similar inputs. → **Client Explanation Simulation.** Expected: simple language/analogy, stay confident, answer calmly.
- **Demo Storytelling** — client struggles to see value in a feature demo. → **Client Demo Role Play.** Expected: Problem → Solution → Impact narrative, connect to business goals.

## Related
[[AI-Ownership-and-Accountability]] · [[Responsible-AI-and-Governance]] · [[Behaviour-MOC]]
