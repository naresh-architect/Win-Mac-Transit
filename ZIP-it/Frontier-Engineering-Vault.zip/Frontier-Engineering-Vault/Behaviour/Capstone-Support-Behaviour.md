---
tags: [behaviour, week6]
---

# Capstone Support (Behavioral)

**Week:** [[Week-6-Nexus]]

## Why Here
The programme's highest-pressure point — teams integrate four weeks of technical work under a live demo deadline while receiving closing feedback on their growth.

## Case Studies
- **Behavioral Coaching** — learner has received feedback on unclear communication with limited improvement. → **Coaching Conversation.** Expected: accept feedback openly, ask clarifying questions, commit to concrete steps.
- **Client Simulation** — client escalates system errors that affected business outcomes, leadership present. → **Executive Q&A Simulation.** Expected: stay composed, own the issue, explain corrective actions, handle questions confidently.

## Related
[[Collaboration-and-Decision-Ownership]] · [[More-Behavioral-Scenarios]] · [[Behaviour-MOC]]
