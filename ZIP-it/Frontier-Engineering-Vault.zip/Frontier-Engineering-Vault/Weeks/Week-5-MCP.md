---
tags: [week, technology]
week: 5
---

# Week 5 — Model Context Protocol: Build, Compose & Deploy

Takes the MCP concepts previewed in [[Week-4-Agentic-AI]] end-to-end: real servers, multi-server composition, client integration, and shipping to a production-like environment.

## Technical Topics
- [[Model-Context-Protocol]] — Tools, Resources, Prompts; architecture; FastMCP; MCP Inspector
- [[Guardrails-and-Content-Safety]] — prompt injection defence, input sanitisation, output filtering, PII handling
- [[Production-Deployment]] — Docker, secrets management, structured logging, health checks

## Behavioral Pairing
- [[Collaboration-and-Decision-Ownership]] — team alignment under disagreement; owning a client cost-vs-accuracy trade-off decision.

## Capstone
- [[BankForge]] — three MCP servers exposing digital banking systems, fictional org [[NeoBank-India]]. Security and compliance are first-class evaluation criteria, not afterthoughts.

## Related
- Previous: [[Week-4-Agentic-AI]]
- Next: [[Week-6-Nexus]]
- [[Technology-MOC]]
