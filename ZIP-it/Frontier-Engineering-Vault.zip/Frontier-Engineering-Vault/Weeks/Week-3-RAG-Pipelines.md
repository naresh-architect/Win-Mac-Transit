---
tags: [week, technology]
week: 3
---

# Week 3 — RAG Pipelines (Retrieval-Augmented Generation)

Covers the full RAG stack from raw text to production-quality retrieval. [[RAGAS-Evaluation]] is introduced at the *start* of the week — learners define what "good" looks like before building anything, then apply evaluation after every pipeline change.

## Technical Topics
- [[RAG-Fundamentals]]
- [[RAGAS-Evaluation]]
- [[Embeddings-and-Vector-Databases]]
- Document ingestion, chunking, hybrid search, query expansion, re-ranking
- Structured/CSV/SQL RAG
- Multimodal RAG (text + tables + images)

## Behavioral Pairing
- [[Client-Communication-and-Storytelling]] — explaining inconsistent retrieval behaviour to a non-technical client; demo storytelling.

## Capstone (three domain options)
- [[CodeCompass]] — event-driven payments architecture Q&A over a real Java/Axon codebase
- [[CourseCompass]] — heterogeneous PDF structure, cross-document topic linking, over the programme's own course material
- [[ClaimSense]] — hybrid structured + unstructured retrieval, fictional org [[SecureShield-Insurance]]

## Related
- Previous: [[Week-2-LLM-Foundations]]
- Next: [[Week-4-Agentic-AI]]
- [[Technology-MOC]]
