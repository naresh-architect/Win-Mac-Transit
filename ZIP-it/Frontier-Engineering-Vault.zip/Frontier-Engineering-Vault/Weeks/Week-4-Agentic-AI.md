---
tags: [week, technology]
week: 4
---

# Week 4 — Agentic AI & Multi-Agent Systems

Moves from retrieval pipelines to autonomous systems that plan, act, and collaborate. Closes with an [[Model-Context-Protocol|MCP]] preview (concepts only) that sets up [[Week-5-MCP]].

## Technical Topics
- [[Multi-Agent-Systems]] — LangChain, AutoGen, CrewAI orchestration patterns
- Human-in-the-loop design
- MCP preview — the "USB-C for AI" concept, no server implementation yet

## Behavioral Pairing
- [[Responsible-AI-and-Governance]] — bias escalation, validation/governance checkpoints.

## Capstone (two domain options)
- [[SupportPilot]] — e-commerce customer support, confidence-threshold escalation, fictional org [[ShopStream-India]]
- [[CareRoute]] — healthcare triage coordination, hard category-based escalation (never confidence-tunable), fictional org [[CareWell-Health-Network]]

The key design contrast between the two: SupportPilot escalates *when the system is unsure*; CareRoute escalates *certain categories unconditionally*, because patient safety demands it regardless of model confidence.

## Related
- Previous: [[Week-3-RAG-Pipelines]]
- Next: [[Week-5-MCP]]
- [[Technology-MOC]]
