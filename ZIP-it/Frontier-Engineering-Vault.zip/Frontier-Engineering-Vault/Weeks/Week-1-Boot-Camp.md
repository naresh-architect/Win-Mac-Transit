---
tags: [week, behaviour]
week: 1
---

# Week 1 — Boot Camp (Professional Foundations)

No LLM, RAG, agentic, or MCP content. Week 1 exists to establish the professional and workplace-behavior baseline that every later technical week — and every later [[Behaviour-MOC|behavioral case study]] — assumes already exists.

## Format
Gamified, trainer-led boot camp, 5 days.

## Covers
- Etiquette & Diversity and Inclusion
- Remote working ethics
- Email etiquette
- Client interfacing skills
- Conference call etiquette
- Teamwork & effective communication
- Interview clinic

## Assessment
- Gamified boot camp scores
- Trainer-based evaluation (new-competency rubric)
- Techstack skill-based behavioral (BH) assessment

## Why It Matters Downstream
Every later behavioral case study — from [[AI-Ownership-and-Accountability]]'s "Issue Escalation Meeting" in [[Week-2-LLM-Foundations]] through the "Executive Q&A Simulation" in [[Week-6-Nexus]] — assumes this baseline of professional conduct is already in place.

## Related
- [[Behaviour-MOC]]
- Next: [[Week-2-LLM-Foundations]]
