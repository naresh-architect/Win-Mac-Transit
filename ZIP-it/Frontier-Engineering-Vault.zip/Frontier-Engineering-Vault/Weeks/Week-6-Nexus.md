---
tags: [week, capstone]
week: 6
---

# Week 6 — Final Integrative Capstone: Nexus

No new instructional content. Every technique from [[Week-2-LLM-Foundations]], [[Week-3-RAG-Pipelines]], [[Week-4-Agentic-AI]], and [[Week-5-MCP]] must operate together in **one connected system** — not four separate demonstrations.

## What Nexus Must Prove

| Prior Week | Demonstrated As |
|---|---|
| [[Week-2-LLM-Foundations]] | Structured, Pydantic-validated intake as the front door |
| [[Week-3-RAG-Pipelines]] | Grounded retrieval reconciling structured + unstructured data, as in [[ClaimSense]] |
| [[Week-4-Agentic-AI]] | Multi-agent pipeline with hard, category-based escalation, as in [[CareRoute]] |
| [[Week-5-MCP]] | All backend access via scoped MCP servers + full guardrails stack, as in [[BankForge]] |

## Capstone
- [[Nexus-Capstone]] — unified financial services concierge, fictional org [[Meridian-Financial-Group]]

## Behavioral Pairing
- [[Capstone-Support-Behaviour]] — coaching conversations on unclear communication; executive Q&A simulation under a client escalation.

## Core Principle
**Integration, not reimplementation.** A team with four excellent but disconnected components has not met the bar — the reviewer traces one real request end-to-end through all four layers.

## Related
- Previous: [[Week-5-MCP]]
- [[Capstones-MOC]]
