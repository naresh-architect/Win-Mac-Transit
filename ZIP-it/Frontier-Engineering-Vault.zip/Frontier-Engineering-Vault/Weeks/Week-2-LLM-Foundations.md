---
tags: [week, technology]
week: 2
---

# Week 2 — LLM Foundations & Prompt Engineering

Bridges the gap between knowing about LLMs and being able to build with them. By Friday, learners build a multi-turn intake assistant with structured output, validated against a real regulatory schema.

## Technical Topics
- [[LLM-APIs-and-Tokens]]
- [[Prompt-Engineering]]
- [[Structured-Output-and-Function-Calling]]
- [[LangChain-Foundations]]
- [[Conversation-Memory]]

## Behavioral Pairing
- [[AI-Ownership-and-Accountability]] — "Issue Escalation Meeting" and "Debugging Discussion" case studies, run alongside the technical labs.

## Capstone
- [[SmartIntake-Pharma]] — pharmaceutical regulatory compliance intake, fictional org [[PharmaCore-India]]
- [[SmartIntake-AML]] — financial services AML compliance intake, fictional org [[FinBridge-Solutions]]

Both share an identical five-layer architecture (API → prompt engineering → function calling/Pydantic → LangChain chains → conversation memory) and the same three conversation paths (happy, partial, fallback).

## Related
- Previous: [[Week-1-Boot-Camp]]
- Next: [[Week-3-RAG-Pipelines]]
- [[Technology-MOC]]
