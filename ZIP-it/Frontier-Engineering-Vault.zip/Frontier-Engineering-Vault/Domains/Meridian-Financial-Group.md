---
tags: [domain, fictional-org]
---

# Meridian Financial Group

**Industry:** Diversified financial services — retail banking, general insurance, wealth management, under one brand
**Used In:** [[Nexus-Capstone]] ([[Week-6-Nexus]])

The only fictional org that's explicitly a synthesis: requires the structured-intake discipline of [[PharmaCore-India]]/[[FinBridge-Solutions]], the grounded-retrieval discipline of [[SecureShield-Insurance]], the multi-agent orchestration of [[CareWell-Health-Network]]/[[ShopStream-India]], and the secure tool-exposure discipline of [[NeoBank-India]] — all at once.

## Related Domains
[[Domains-MOC]]
