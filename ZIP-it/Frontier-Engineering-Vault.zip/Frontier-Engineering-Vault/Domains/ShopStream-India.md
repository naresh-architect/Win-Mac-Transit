---
tags: [domain, fictional-org]
---

# ShopStream India

**Industry:** E-commerce customer support
**Used In:** [[SupportPilot]] ([[Week-4-Agentic-AI]])

Ticket classification, account/order lookup, resolution drafting, and confidence-threshold escalation — a natural fit for multi-agent role division.

## Related Domains
[[CareWell-Health-Network]] · [[Domains-MOC]]
