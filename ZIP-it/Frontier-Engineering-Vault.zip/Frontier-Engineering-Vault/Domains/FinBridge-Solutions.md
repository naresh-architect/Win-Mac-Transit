---
tags: [domain, fictional-org]
---

# FinBridge Solutions

**Industry:** Financial services — AML & compliance (SAR/STR filing, KYC exceptions, sanctions screening, fraud investigation)
**Jurisdictions:** India, UK, Singapore, US, EU
**Used In:** [[SmartIntake-AML]] ([[Week-2-LLM-Foundations]])

Adds a jurisdiction dimension and the *tipping-off* negative-prompting constraint not present in the pharma variant.

## Related Domains
[[PharmaCore-India]] · [[NeoBank-India]] · [[Domains-MOC]]
