---
tags: [domain, fictional-org]
---

# CareWell Health Network

**Industry:** Multi-specialty healthcare — appointment & triage coordination
**Used In:** [[CareRoute]] ([[Week-4-Agentic-AI]])

The only domain where human-in-the-loop escalation is a **hard safety requirement**, not a confidence-threshold nicety — patient-safety stakes force a more conservative agent-handoff design than [[ShopStream-India]]'s business-risk-only logic.

## Related Domains
[[Domains-MOC]]
