---
tags: [domain, fictional-org]
---

# NeoBank India

**Industry:** Digital banking — accounts, transactions, loans/products, compliance/KYC, customer communication
**Used In:** [[BankForge]] ([[Week-5-MCP]])

Forces security- and compliance-first MCP design: scoped access, data minimisation, and auditability are first-class requirements.

## Related Domains
[[FinBridge-Solutions]] · [[Meridian-Financial-Group]] · [[Domains-MOC]]
