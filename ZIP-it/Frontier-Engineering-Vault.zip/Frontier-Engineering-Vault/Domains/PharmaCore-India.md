---
tags: [domain, fictional-org]
---

# PharmaCore India

**Industry:** Pharmaceutical regulatory compliance (PV, CMC, clinical, labelling, submissions)
**Used In:** [[SmartIntake-Pharma]] ([[Week-2-LLM-Foundations]])

Strict schema requirements (enums, required validators) and real consequences for extraction failure (missed regulatory deadlines, audit gaps) make this a rigorous first domain exercise.

## Related Domains
[[FinBridge-Solutions]] · [[Domains-MOC]]
