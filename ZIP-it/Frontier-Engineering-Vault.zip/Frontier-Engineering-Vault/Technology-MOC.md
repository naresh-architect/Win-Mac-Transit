---
tags: [moc]
---

# Technology — Map of Content

## Week 2 — LLM Foundations
[[LLM-APIs-and-Tokens]] · [[Prompt-Engineering]] · [[Structured-Output-and-Function-Calling]] · [[LangChain-Foundations]] · [[Conversation-Memory]]

## Week 3 — RAG
[[RAG-Fundamentals]] · [[Embeddings-and-Vector-Databases]] · [[RAGAS-Evaluation]]

## Week 4 — Agentic AI
[[Multi-Agent-Systems]] · [[Model-Context-Protocol]] (preview)

## Week 5 — MCP
[[Model-Context-Protocol]] (full build) · [[Guardrails-and-Content-Safety]] · [[Production-Deployment]]

Back to [[00-Home]]
