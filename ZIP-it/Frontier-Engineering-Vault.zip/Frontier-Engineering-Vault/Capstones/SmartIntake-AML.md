---
tags: [capstone, week2]
---

# SmartIntake — Financial Services AML Compliance

**Week:** [[Week-2-LLM-Foundations]]
**Fictional Org:** [[FinBridge-Solutions]]
**Duration:** 1 day (Friday) · Solo or pairs

## What Gets Built
A CLI intake assistant for a compliance officer, AML analyst, or fraud investigator. Extracts five fields:

`query_type`, `regulation_ref`, `jurisdiction`, `urgency`, `submitting_team`

Validated against enums covering FATF/BSA/FCA/RBI/OFAC and multi-jurisdiction values (India/UK/Singapore/US/EU).

## Distinct Constraint: Tipping-Off Risk
The system must never ask a question that could constitute *tipping off* a customer about an ongoing investigation — a compliance-critical negative-prompting case not present in the pharma variant. Log-safety extends to account numbers, transaction references, and case IDs.

## Consolidates
[[LLM-APIs-and-Tokens]] · [[Prompt-Engineering]] · [[Structured-Output-and-Function-Calling]] · [[LangChain-Foundations]] · [[Conversation-Memory]]

## Sibling Capstone
- [[SmartIntake-Pharma]] — same architecture, pharma domain
