---
tags: [capstone, week3]
---

# CourseCompass — Internal Training Documentation

**Week:** [[Week-3-RAG-Pipelines]]
**Domain:** The programme's own course material (30–40+ PDFs)
**Duration:** 2–3 days · Teams of 2–3

## The Problem
Course material grows fast — book-style PDFs (chapters, tables, code blocks) and slide-deck PDFs (sparse, visual-first) both exist, often covering the *same* topic in different formats.

## What Gets Built
A RAG assistant that ingests all course PDFs, chunks book-style and slide-style content **differently**, links related coverage of the same topic across documents, and cites the exact document + section/slide.

## Primary RAG Skill
Heterogeneous PDF structure + cross-document topic linking — see [[RAG-Fundamentals]] and [[Embeddings-and-Vector-Databases]].

## Sibling Capstones
- [[CodeCompass]] — technical Q&A over a codebase
- [[ClaimSense]] — hybrid structured/unstructured retrieval
