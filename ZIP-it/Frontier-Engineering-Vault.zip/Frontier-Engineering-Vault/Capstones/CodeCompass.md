---
tags: [capstone, week3]
---

# CodeCompass — Event-Driven Payments Architecture

**Week:** [[Week-3-RAG-Pipelines]]
**Domain:** Java/Axon Framework, event sourcing, CQRS (no single fictional org — a real-style codebase)
**Duration:** 2–3 days · Teams of 2–3

## The Problem
A new engineer joins a payments platform spanning 11 microservices. A single business transaction is scattered across command handlers, event handlers, and sagas in different services — hard to trace by reading code alone.

## What Gets Built
An assistant answering natural-language questions ("how does a settlement failure get reconciled?") grounded in the platform's own README, AsciiDoc architecture docs, correlation/tracing notes, and code.

## Primary RAG Skill
Technical Q&A grounded in code + architecture docs — see [[RAG-Fundamentals]].

## Sibling Capstones
- [[CourseCompass]] — heterogeneous PDF structure
- [[ClaimSense]] — hybrid structured/unstructured retrieval
