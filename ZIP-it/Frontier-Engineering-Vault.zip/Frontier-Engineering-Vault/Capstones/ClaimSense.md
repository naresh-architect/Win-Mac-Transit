---
tags: [capstone, week3]
---

# ClaimSense — Insurance Claims Intelligence

**Week:** [[Week-3-RAG-Pipelines]]
**Fictional Org:** [[SecureShield-Insurance]]
**Duration:** 2–3 days · Teams of 2–3

## The Problem
Claims support relies on policy wording PDFs, IRDAI regulatory circulars, *and* a structured claims history database. A question like "was this rejection consistent with the exclusion, and did we settle in time?" needs all three reconciled.

## What Gets Built
An assistant that routes each question to the right retrieval strategy — semantic document search, structured claims lookup, or both — and reconciles them into one cited answer.

## Primary RAG Skill
Genuine hybrid retrieval — the only Week 3 option requiring both unstructured *and* structured/SQL-style lookup in the same answer.

## Forward Link
This hybrid-reconciliation pattern is exactly what [[Nexus-Capstone]] requires at full scale in [[Week-6-Nexus]].

## Sibling Capstones
- [[CodeCompass]] · [[CourseCompass]]
