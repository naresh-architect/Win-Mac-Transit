---
tags: [capstone, week5]
---

# BankForge — Digital Banking MCP Ecosystem

**Week:** [[Week-5-MCP]]
**Fictional Org:** [[NeoBank-India]]
**Duration:** 2–3 days · Teams of 2–3

## The Problem
NeoBank's AI assistant can't reach any of its four disconnected internal systems: core banking database, loan/product catalogue, compliance/KYC rules engine, customer communication platform.

## What Gets Built
Three [[Model-Context-Protocol|MCP]] servers exposing these systems to any compatible AI client — cleanly, securely, and in compliance with banking regulations. No hardcoded integration logic; no exposing data the client shouldn't see.

## Evaluation Criteria
Security and compliance are first-class, not afterthoughts — scoped access, data minimisation, at least one compliance check demonstrated live.

## Forward Link
BankForge's MCP-first, scoped-access pattern is the direct template for [[Nexus-Capstone]]'s backend access layer in [[Week-6-Nexus]].
