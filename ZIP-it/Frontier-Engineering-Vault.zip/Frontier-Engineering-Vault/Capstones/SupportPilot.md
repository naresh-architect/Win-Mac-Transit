---
tags: [capstone, week4]
---

# SupportPilot — E-Commerce Customer Support

**Week:** [[Week-4-Agentic-AI]]
**Fictional Org:** [[ShopStream-India]]
**Duration:** 2–3 days · Teams of 2–3

## The Problem
Hundreds of daily tickets, each needing: classify → look up account/order history → search knowledge base → draft response → check accuracy/compliance → resolve or escalate → log outcome.

## Escalation Logic
**Confidence-threshold-driven** — escalates to a human only when the system is unsure or the issue type requires it.

## Multi-Agent Skill
Standard classify → retrieve → draft → validate → escalate pipeline — see [[Multi-Agent-Systems]].

## Contrast
- [[CareRoute]] — same architecture, but escalation is **category-driven and non-negotiable**, not confidence-based, because of patient-safety stakes.
