---
tags: [capstone, week4]
---

# CareRoute — Healthcare Appointment & Triage Coordination

**Week:** [[Week-4-Agentic-AI]]
**Fictional Org:** [[CareWell-Health-Network]]
**Duration:** 2–3 days · Teams of 2–3

## The Problem
Patient enquiries need urgency assessment, specialty routing, scheduling, and insurance pre-authorisation checks — where a missed urgent case carries real patient-safety risk.

## Escalation Logic
**Category-driven, hard rule — not confidence-tunable.** Certain symptom categories (chest pain, breathing difficulty, mentions of self-harm) must *always* reach a human clinician, regardless of model confidence, and cannot be bypassed by rephrasing.

## Hard Constraint
CareRoute must never present itself as providing a medical diagnosis.

## Multi-Agent Skill
Mandatory human-in-the-loop gating as a safety requirement, not an optimisation — see [[Multi-Agent-Systems]].

## Forward Link
This non-negotiable escalation pattern reappears, translated to a financial-services context, in [[Nexus-Capstone]].

## Contrast
- [[SupportPilot]] — confidence-threshold escalation instead
