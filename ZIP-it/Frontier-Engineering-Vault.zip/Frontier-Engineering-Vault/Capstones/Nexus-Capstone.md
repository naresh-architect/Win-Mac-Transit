---
tags: [capstone, week6]
---

# Nexus — Unified Financial Services Concierge

**Week:** [[Week-6-Nexus]]
**Fictional Org:** [[Meridian-Financial-Group]]
**Duration:** 3–4 days · Teams of 3–4
**Deliverables:** Working end-to-end system + architecture document + deployment evidence + 20-minute demo

## The Problem
Meridian's banking, insurance, and wealth management lines each run separate service operations, knowledge bases, and backend systems. Cross-product questions ("can I auto-pay my insurance premium from my home loan account, and is that covered?") can't be answered by any single team.

## What Nexus Must Do
1. **Intake & classify** — validated, typed schema, same rigor as [[SmartIntake-Pharma]]/[[SmartIntake-AML]]
2. **Retrieve & reconcile** — structured account/policy data + unstructured product/regulatory docs, as in [[ClaimSense]]
3. **Orchestrate multi-agent response** — draft → validate → escalate, with hard category-based escalation (financial hardship, safeguarding) as in [[CareRoute]]
4. **Act only through MCP** — scoped, minimal-necessary access, as in [[BankForge]], wrapped in [[Guardrails-and-Content-Safety]]
5. **Be deployed** — containerised via Docker Compose, per [[Production-Deployment]]

## Core Principle
Integration, not reimplementation — one real request traced end-to-end through all four layers.

## Demo Requirement
- **Part 1:** end-to-end happy path across all four layers
- **Part 2:** a guardrail/injection block *and* an unbypassable hard escalation

## Related
- [[Week-6-Nexus]] · [[Capstones-MOC]]
