---
tags: [capstone, week2]
---

# SmartIntake — Pharmaceutical Regulatory Compliance

**Week:** [[Week-2-LLM-Foundations]]
**Fictional Org:** [[PharmaCore-India]]
**Duration:** 1 day (Friday) · Solo or pairs

## What Gets Built
A CLI intake assistant that accepts free-text regulatory queries from a compliance/regulatory affairs team member and uses [[Structured-Output-and-Function-Calling|function calling]] to extract five fields:

`query_type`, `regulation_ref`, `product_area`, `urgency`, `submitting_team`

Validated with a Pydantic model enforcing domain enums (FDA/EMA/CDSCO, GxP frameworks). Stores a **log-safe** JSON record — no sensitive identifiers or raw free-text in plain storage.

## Consolidates
[[LLM-APIs-and-Tokens]] · [[Prompt-Engineering]] · [[Structured-Output-and-Function-Calling]] · [[LangChain-Foundations]] · [[Conversation-Memory]]

## Why This Domain
Strict schema requirements, real consequences for extraction failure (missed regulatory deadlines, audit gaps), rich natural-language variation.

## Sibling Capstone
- [[SmartIntake-AML]] — same architecture, financial-services domain, swaps `product_area` for `jurisdiction`
