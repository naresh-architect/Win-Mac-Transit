---
tags: [behaviour, appendix]
---

# More Behavioral Scenarios (Appendix Bank)

A broader bank of AI-ownership and governance scenarios for additional practice, make-up sessions, or extra repetition on a specific competency. Supplements [[AI-Ownership-and-Accountability]], [[Client-Communication-and-Storytelling]], [[Responsible-AI-and-Governance]], [[Collaboration-and-Decision-Ownership]], and [[Capstone-Support-Behaviour]].

| # | Scenario | Focus |
|---|---|---|
| 1 | AI Hallucination Handling | Accountability, ethics, communication |
| 2 | AI Code Ownership Conflict | Ownership mindset, governance |
| 3 | Speed vs Validation | Decision-making under pressure, integrity |
| 4 | AI Bias / Ethical Risk | Ethical awareness, courage |
| 5 | AI vs Human Judgment | Critical thinking, decision ownership |
| 6 | Client Escalation Scenario | Client communication, professional ownership |
| 7 | AI Governance in Teams | Governance mindset, process thinking |

## Key Theme Across All Seven
The engineer owns the outcome even when AI was used to produce it — disclosure, validation, and escalation are not optional extras.

## Related
[[Behaviour-MOC]] · [[00-Home]]
