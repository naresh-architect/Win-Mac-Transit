---
source: Learning How to Learn
---

# Working Memory
The mental school bag. Limited capacity.