---
source: Learning How to Learn
---

# Recall
Retrieving information strengthens memory.