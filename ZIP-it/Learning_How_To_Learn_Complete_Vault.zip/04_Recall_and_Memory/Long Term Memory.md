---
source: Learning How to Learn
---

# Long Term Memory
The mental locker. Stores skills, concepts and chunks.