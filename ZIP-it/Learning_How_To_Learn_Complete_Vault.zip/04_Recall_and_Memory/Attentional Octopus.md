---
source: Learning How to Learn
---

# Attentional Octopus
Metaphor for working memory and attention.