---
source: Learning How to Learn
---

# Active Recall
Retrieving information without looking at notes.