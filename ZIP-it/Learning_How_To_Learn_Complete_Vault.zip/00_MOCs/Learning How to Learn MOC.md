# Learning How to Learn

## Focus
- [[Focused Mode]]
- [[Diffuse Mode]]

## Productivity
- [[Procrastination]]
- [[Pomodoro Technique]]

## Brain Biology
- [[Neuroplasticity]]
- [[Dendritic Spines]]
- [[Sleep and Learning]]

## Memory
- [[Recall]]
- [[Active Recall]]
- [[Working Memory]]
- [[Long Term Memory]]

## Memory Techniques
- [[Visualization]]
- [[Mnemonic]]
- [[Memory Palace]]

## Expertise
- [[Chunking]]
- [[Expertise]]
- [[Deliberate Practice]]
