---
source: Learning How to Learn
---

# Sleep and Learning
Sleep consolidates learning and strengthens pathways.