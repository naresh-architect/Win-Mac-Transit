---
source: Learning How to Learn
---

# Memory Consolidation
Process of stabilizing memories.