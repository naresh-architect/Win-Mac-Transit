---
source: Learning How to Learn
---

# Dendritic Spines
Grow during learning and strengthen during sleep.