---
source: Learning How to Learn
---

# Neuroplasticity
Learning physically changes the brain.