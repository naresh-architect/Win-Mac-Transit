---
source: Learning How to Learn
---

# Diffuse Mode
Broad thinking mode that helps create new connections.