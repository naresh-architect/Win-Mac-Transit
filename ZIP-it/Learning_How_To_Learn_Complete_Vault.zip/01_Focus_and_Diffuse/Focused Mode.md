---
source: Learning How to Learn
---

# Focused Mode
Concentrated attention for solving familiar problems.