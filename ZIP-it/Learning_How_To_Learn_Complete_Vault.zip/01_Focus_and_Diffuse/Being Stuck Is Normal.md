---
source: Learning How to Learn
---

# Being Stuck Is Normal
Being stuck is a signal to switch from focused mode to diffuse mode.