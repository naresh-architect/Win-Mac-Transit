---
source: Learning How to Learn
---

# Teaching Creates Learning
Teaching reveals gaps and strengthens understanding.