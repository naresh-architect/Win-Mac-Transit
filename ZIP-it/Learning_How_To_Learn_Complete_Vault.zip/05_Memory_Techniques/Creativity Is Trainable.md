---
source: Learning How to Learn
---

# Creativity Is Trainable
Memory creativity improves with practice.