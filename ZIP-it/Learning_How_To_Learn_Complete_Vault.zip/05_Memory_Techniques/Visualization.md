---
source: Learning How to Learn
---

# Visualization
Convert abstract facts into vivid images.