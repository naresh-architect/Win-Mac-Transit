---
source: Learning How to Learn
---

# Mnemonic
Memory aid using associations.