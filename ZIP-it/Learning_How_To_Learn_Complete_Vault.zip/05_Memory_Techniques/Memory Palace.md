---
source: Learning How to Learn
---

# Memory Palace
Store information in familiar locations.