---
source: Learning How to Learn
---

# Procrastination
Avoiding tasks due to discomfort.