---
source: Learning How to Learn
---

# Insular Cortex
Activates when thinking about unpleasant tasks.