---
source: Learning How to Learn
---

# Pomodoro Technique
25 minutes focus + 5-10 minutes break.