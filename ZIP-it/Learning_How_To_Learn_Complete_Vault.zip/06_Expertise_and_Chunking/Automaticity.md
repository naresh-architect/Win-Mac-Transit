---
source: Learning How to Learn
---

# Automaticity
Skills become effortless through chunking and practice.