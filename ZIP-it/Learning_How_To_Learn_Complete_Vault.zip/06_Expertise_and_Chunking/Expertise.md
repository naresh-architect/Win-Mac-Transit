---
source: Learning How to Learn
---

# Expertise
Experts have many well-developed chunks.