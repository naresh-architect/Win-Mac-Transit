---
source: Learning How to Learn
---

# Avoid Lazy Learning
Do not repeatedly practice only what is easy.