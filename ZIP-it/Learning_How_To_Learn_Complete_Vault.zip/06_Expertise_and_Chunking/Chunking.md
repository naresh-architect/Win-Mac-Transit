---
source: Learning How to Learn
---

# Chunking
Many small ideas become one retrievable unit.