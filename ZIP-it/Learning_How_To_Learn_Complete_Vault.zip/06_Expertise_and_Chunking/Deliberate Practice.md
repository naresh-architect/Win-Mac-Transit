---
source: Learning How to Learn
---

# Deliberate Practice
Practice difficult things with feedback.